let saldo = 0;
let moedasElement = document.getElementById('moedas');

function assistirAd() {
    // Simula a visualização do anúncio
    alert("Você está assistindo ao anúncio!");

    // Após um tempo (simulando o tempo de um anúncio), adiciona moedas aleatórias ao saldo
    setTimeout(() => {
        // Gera um número aleatório entre 5 e 50
        let moedasGanhas = Math.floor(Math.random() * 46) + 5;
        
        // Atualiza o saldo de moedas
        saldo += moedasGanhas;
        moedasElement.textContent = saldo;

        // Mensagem informando quantas moedas foram ganhas
        alert(`Você ganhou ${moedasGanhas} moedas!`);
    }, 3000); // Simula um tempo de 3 segundos para "assistir" o anúncio
}
